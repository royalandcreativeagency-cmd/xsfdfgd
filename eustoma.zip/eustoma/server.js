// EUSTOMA store backend. No dependencies. Run:  ADMIN_PASSWORD=yourpassword node server.js
// Store: http://localhost:3000   Admin: http://localhost:3000/admin
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,PASS=process.env.ADMIN_PASSWORD||'eustoma123',DB=path.join(__dirname,'data.json');
if(!process.env.ADMIN_PASSWORD)console.log('WARNING: using the default admin password. Set ADMIN_PASSWORD before going live.');
const pay=(id,label,on,note)=>({id,label,on,note});
let db;try{db=JSON.parse(fs.readFileSync(DB,'utf8'))}catch{db={next:1001,orders:[],products:JSON.parse(fs.readFileSync(path.join(__dirname,'products.json'),'utf8')),settings:{phone:'0346 8042900',whatsapp:'923468042900',delivery:250,freeFrom:7000,payments:[
 pay('cod','Cash on delivery',true,''),
 pay('jazzcash','JazzCash',true,'Send the total to JazzCash 0346 8042900, then enter the transaction ID below.'),
 pay('easypaisa','Easypaisa',true,'Send the total to Easypaisa 0346 8042900, then enter the transaction ID below.'),
 pay('bank','Bank transfer',false,'Bank: (set in Admin)\nAccount title: (set in Admin)\nAccount no / IBAN: (set in Admin)'),
 pay('card','Card (payment link on WhatsApp)',false,'We will send a secure payment link on WhatsApp after you place the order.')]}}}
const save=()=>{fs.writeFileSync(DB+'.tmp',JSON.stringify(db));fs.renameSync(DB+'.tmp',DB)};save();
const tokens=new Map(),fails=new Map(),STAT=['Pending','Confirmed','Dispatched','Delivered','Cancelled'],PSTAT=['COD','Awaiting verification','Paid','Failed','Refunded'];
const str=(v,n)=>typeof v==='string'?v.trim().slice(0,n):'',num=v=>Number.isFinite(+v)?+v:NaN,digits=v=>String(v||'').replace(/\D/g,'');
const send=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
const body=req=>new Promise((ok,no)=>{let b='';req.on('data',c=>{b+=c;if(b.length>2e5){no();req.destroy()}});req.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch{no()}})});
const authed=req=>{const t=(req.headers.authorization||'').replace('Bearer ','');const e=tokens.get(t);return e&&e>Date.now()};
const file=(res,f,type)=>fs.readFile(path.join(__dirname,f),(e,d)=>{if(e){res.writeHead(404);return res.end('Not found')}res.writeHead(200,{'Content-Type':type,'X-Content-Type-Options':'nosniff'});res.end(d)});
http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://x'),p=u.pathname,m=req.method;
 try{
 if(m==='GET'&&p==='/')return file(res,'EUSTOMA.html','text/html; charset=utf-8');
 if(m==='GET'&&p==='/admin')return file(res,'admin.html','text/html; charset=utf-8');
 if(m==='GET'&&p==='/api/catalog')return send(res,200,{settings:db.settings,products:db.products.map(({id,name,price,stock,hidden})=>({id,name,price,stock,hidden}))});
 if(m==='POST'&&p==='/api/orders'){
  const b=await body(req),S=db.settings,name=str(b.name,80),phone=str(b.phone,25),address=str(b.address,300),city=str(b.city,60),pm=S.payments.find(x=>x.id===b.pay&&x.on),txn=str(b.txn,60);
  if(!name||digits(phone).length<10||!address||!city)return send(res,400,{error:'Please fill in your name, a valid phone number, address and city.'});
  if(!pm)return send(res,400,{error:'Choose a payment method.'});
  if(pm.id!=='cod'&&pm.id!=='card'&&txn.length<4)return send(res,400,{error:'Enter your payment transaction ID.'});
  if(!Array.isArray(b.items)||!b.items.length||b.items.length>50)return send(res,400,{error:'Your cart is empty.'});
  const items=[];for(const it of b.items){const pr=db.products.find(x=>x.id===it.id),qty=Math.floor(num(it.qty)),size=str(it.size,4);
   if(!pr||pr.hidden||!(qty>=1&&qty<=20)||!['S','M','L','XL'].includes(size))return send(res,400,{error:'An item in your cart is no longer available.'});
   if(pr.stock!==null&&pr.stock<qty)return send(res,400,{error:pr.name+' has only '+pr.stock+' left.'});
   items.push({id:pr.id,name:pr.name,size,qty,price:pr.price})}
  items.forEach(i=>{const pr=db.products.find(x=>x.id===i.id);if(pr.stock!==null)pr.stock-=i.qty});
  const sub=items.reduce((a,i)=>a+i.price*i.qty,0),delivery=sub>=S.freeFrom?0:S.delivery,date=new Date();
  const o={id:'EUS-'+db.next++,created:date.toISOString(),name,phone,address,city,pay:pm.id,payLabel:pm.label,txn,items,sub,delivery,total:sub+delivery,status:'Pending',payStatus:pm.id==='cod'?'COD':'Awaiting verification'};
  db.orders.unshift(o);save();
  return send(res,200,{id:o.id,total:o.total,date:date.toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})});
 }
 if(m==='GET'&&p==='/api/track'){const o=db.orders.find(x=>x.id===(u.searchParams.get('id')||'').toUpperCase()&&digits(x.phone).slice(-10)===digits(u.searchParams.get('phone')).slice(-10));
  return o?send(res,200,{id:o.id,status:o.status,total:o.total,date:new Date(o.created).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})}):send(res,404,{});}
 if(m==='POST'&&p==='/api/admin/login'){
  const ip=req.socket.remoteAddress,f=fails.get(ip)||{n:0,t:Date.now()};if(Date.now()-f.t>9e5){f.n=0;f.t=Date.now()}
  if(f.n>=8)return send(res,429,{error:'Too many attempts. Try again in 15 minutes.'});
  const b=await body(req),a=crypto.createHash('sha256').update(String(b.password)).digest(),c=crypto.createHash('sha256').update(PASS).digest();
  if(!crypto.timingSafeEqual(a,c)){f.n++;fails.set(ip,f);return send(res,401,{error:'Wrong password.'})}
  const t=crypto.randomBytes(24).toString('hex');tokens.set(t,Date.now()+12*36e5);return send(res,200,{token:t});
 }
 if(p.startsWith('/api/admin/')){
  if(!authed(req))return send(res,401,{error:'Please sign in.'});
  if(m==='GET'&&p==='/api/admin/data')return send(res,200,{orders:db.orders,products:db.products,settings:db.settings,STAT,PSTAT});
  if(m==='PATCH'&&p.startsWith('/api/admin/orders/')){const o=db.orders.find(x=>x.id===p.split('/').pop()),b=await body(req);if(!o)return send(res,404,{error:'No such order.'});
   if(b.status!==undefined){if(!STAT.includes(b.status))return send(res,400,{error:'Bad status.'});
    if(b.status==='Cancelled'&&o.status!=='Cancelled')o.items.forEach(i=>{const pr=db.products.find(x=>x.id===i.id);if(pr&&pr.stock!==null)pr.stock+=i.qty});o.status=b.status}
   if(b.payStatus!==undefined){if(!PSTAT.includes(b.payStatus))return send(res,400,{error:'Bad payment status.'});o.payStatus=b.payStatus}
   save();return send(res,200,o)}
  if(m==='PUT'&&p==='/api/admin/products'){const b=await body(req);if(!Array.isArray(b.products))return send(res,400,{error:'Bad data.'});
   for(const x of b.products){const pr=db.products.find(y=>y.id===x.id);if(!pr)continue;const n=str(x.name,80),pc=Math.round(num(x.price)),st=x.stock===null||x.stock===''?null:Math.floor(num(x.stock));
    if(n)pr.name=n;if(pc>0)pr.price=pc;pr.stock=st===null||st>=0?st:0;pr.hidden=!!x.hidden}
   save();return send(res,200,{ok:1})}
  if(m==='PUT'&&p==='/api/admin/settings'){const b=await body(req),S=db.settings,d=Math.round(num(b.delivery)),f=Math.round(num(b.freeFrom));
   if(!(d>=0)||!(f>=0)||!Array.isArray(b.payments))return send(res,400,{error:'Check the numbers.'});
   S.phone=str(b.phone,25)||S.phone;S.whatsapp=digits(b.whatsapp)||S.whatsapp;S.delivery=d;S.freeFrom=f;
   S.payments=S.payments.map(x=>{const y=b.payments.find(z=>z.id===x.id)||{};return{id:x.id,label:str(y.label,60)||x.label,on:!!y.on,note:str(y.note,600)}});
   if(!S.payments.some(x=>x.on))S.payments[0].on=true;save();return send(res,200,{ok:1})}
 }
 send(res,404,{error:'Not found'});
 }catch{send(res,400,{error:'Bad request'})}
}).listen(PORT,()=>console.log('EUSTOMA store on http://localhost:'+PORT+'  admin: /admin'));
